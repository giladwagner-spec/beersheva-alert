// api/last-alert.js
// Vercel Serverless Function — פועל בצד השרת, ללא CORS

const HISTORY_URL = 'https://www.oref.org.il/WarningMessages/History/AlertsHistory.json';

const BEER_SHEVA = ['באר שבע', 'באר-שבע'];

function isBeerSheva(str) {
  if (!str) return false;
  return BEER_SHEVA.some(k => str.includes(k));
}

function parseDateTime(item) {
  if (item.alertDate) {
    const d = new Date(item.alertDate.replace(' ', 'T'));
    if (!isNaN(d)) return d;
  }
  if (item.date && item.time) {
    const [day, month, year] = item.date.split('.');
    const [hh, mm] = item.time.split(':');
    const d = new Date(year, month - 1, day, hh, mm);
    if (!isNaN(d)) return d;
  }
  return null;
}

export default async function handler(req, res) {
  // CORS headers — מאפשר לכל דומיין לקרוא את התגובה
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Cache-Control', 's-maxage=60, stale-while-revalidate');

  try {
    const response = await fetch(HISTORY_URL, {
      headers: {
        'Accept': 'application/json',
        'Referer': 'https://www.oref.org.il/',
        'X-Requested-With': 'XMLHttpRequest',
        'User-Agent': 'Mozilla/5.0',
      },
    });

    if (!response.ok) throw new Error(`oref HTTP ${response.status}`);

    const text = await response.text();
    const data = JSON.parse(text.replace(/^\uFEFF/, '').trim());

    const list = Array.isArray(data) ? data : (data.data || data.alerts || []);

    const candidates = list
      .filter(item => {
        const city = item.data || item.city || item.areaname || '';
        const cat  = String(item.category || item.cat || '1');
        return isBeerSheva(city) && (cat === '1' || cat === '');
      })
      .map(item => ({ item, date: parseDateTime(item) }))
      .filter(x => x.date)
      .sort((a, b) => b.date - a.date);

    if (!candidates.length) {
      return res.json({ ok: true, alert: null, message: 'לא נמצאה אזעקה בבאר שבע בהיסטוריה הזמינה' });
    }

    const { item, date } = candidates[0];
    res.json({
      ok: true,
      alert: {
        timestamp: date.toISOString(),
        epochMs:   date.getTime(),
        area:      item.data || item.city || 'באר שבע',
      }
    });

  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
}
